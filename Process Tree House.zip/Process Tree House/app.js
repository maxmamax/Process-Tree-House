const fs = require('fs');
var numVal = 0;

//Read File
fs.readFile('data.txt', 'utf8', async (err, data) => {
  if (err) {
    console.error(err);
    return;
  }

  var str = data.trim().replace(' ','').split(/\r?\n/);
  var arrDimI = str.length;
  var arrDimII = str[0].length;
      numVal = (arrDimI*2) + (arrDimII*2) - 4; // Calculate number of edges

  for(let i=1 ; i<arrDimI - 1 ; i++){
    for(let ii=1 ; ii<arrDimII -1 ; ii++){
        var vLeft = await cLeft(str,str[i][ii],i,ii,arrDimII);
        var vRight = await cRight(str,str[i][ii],i,ii,arrDimII);
        var vUp = await cUp(str,str[i][ii],i,ii,arrDimI);
        var vDown = await cDown(str,str[i][ii],i,ii,arrDimI);

        if(vLeft == true || vRight == true || vUp == true || vDown == true){
          numVal++;
        }
      }
    }
    console.log(numVal);
});

//Function Check Left Side
async function cLeft(str,val,iDimI,iDimII,c){
    return new Promise((resolve) => {
        // console.log('check left');
        for(var i = iDimII - 1; i >= 0 ; i--){
            if(parseInt(str[iDimI][i]) >= parseInt(val)){
                resolve(false);
            }
        }
        resolve(true);
    })
}

//Function Check Right Side
async function cRight(str,val,iDimI,iDimII,c){
    return new Promise((resolve) => {
        // console.log('check right');
        for(var i = iDimII + 1; i < c  ; i++){
            if(parseInt(str[iDimI][i]) >= parseInt(val)){
                resolve(false);
            }
        }
        resolve(true);
    })
}

//Function Check Up Side
async function cUp(str,val,iDimI,iDimII,c){
    return new Promise((resolve) => {
      // console.log('check up');
        for(var i = iDimI - 1 ; i >= 0 ; i--){
            if(parseInt(str[i][iDimII]) >= parseInt(val)){
                resolve(false);
            }
        }
        resolve(true);
    })
}

//Function Check Down Side
async function cDown(str,val,iDimI,iDimII,c){
    return new Promise((resolve) => {
        // console.log('check down');
        for(var i = iDimI + 1 ; i < c ; i++){
            if(parseInt(str[i][iDimII]) >= parseInt(val)){
                resolve(false);
            }
        }
        resolve(true);
    })
}
